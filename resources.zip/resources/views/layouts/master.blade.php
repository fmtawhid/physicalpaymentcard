<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>{{ $siteSettings->site_name }} - Virtual Mastercard</title>

  <!-- Tailwind CSS CDN -->
  <script src="https://cdn.tailwindcss.com"></script>
  @stack('scripts')

  <script>
    tailwind.config = {
      theme: {
        extend: {
          fontFamily: {
            sans: ['Inter', 'ui-sans-serif', 'system-ui', 'sans-serif']
          },
          boxShadow: {
            soft: '0 12px 40px rgba(15, 23, 42, 0.08)',
            card: '0 8px 30px rgba(15, 23, 42, 0.06)'
          }
        }
      }
    }
  </script>

  <style>
    html { scroll-behavior: smooth; }
    body { background: #f8fafc; color: #0f172a; }
    .gradient-bg {
      background:
        radial-gradient(circle at 15% 20%, rgba(59,130,246,.16), transparent 32%),
        radial-gradient(circle at 85% 10%, rgba(16,185,129,.12), transparent 30%),
        linear-gradient(135deg, #f8fbff 0%, #ffffff 52%, #f0fdf8 100%);
    }
    .glass {
      background: rgba(255,255,255,.78);
      backdrop-filter: blur(16px);
      -webkit-backdrop-filter: blur(16px);
    }
    .rate-row:hover { background: #f8fafc; }
    .fade-up {
      animation: fadeUp .55s ease both;
    }
    @keyframes fadeUp {
      from { opacity: 0; transform: translateY(12px); }
      to { opacity: 1; transform: translateY(0); }
    }
    .pulse-dot { animation: pulseDot 1.8s infinite; }
    .language-option.active { background: #0f172a; color: #fff; }
    @keyframes pulseDot {
      0%, 100% { box-shadow: 0 0 0 0 rgba(16,185,129,.35); }
      50% { box-shadow: 0 0 0 8px rgba(16,185,129,0); }
    }
  </style>
</head>

<body class="font-sans">

  <div class="bg-slate-950 text-white text-sm">
    <div class="max-w-7xl mx-auto px-4 py-2.5 flex flex-col sm:flex-row items-center justify-center gap-2 text-center">
      <span class="inline-flex items-center gap-2">
        <span class="h-2 w-2 rounded-full bg-emerald-400 pulse-dot"></span>
        Virtual card delivery: usually {{ $siteSettings->order_processing_time ?: '5–15 minutes' }}
      </span>
      <span class="hidden sm:inline text-slate-500">•</span>
      <a href="{{ route('home') }}#support" class="text-emerald-300 hover:text-emerald-200">Need help? Contact us</a>
    </div>
  </div>

  <!-- Navbar -->
  <header class="sticky top-0 z-50 glass border-b border-slate-200/70">
    <nav class="max-w-7xl mx-auto px-4 h-18 min-h-[72px] flex items-center justify-between">
      <a href="{{ route('home') }}" class="flex items-center gap-3">
        <div class="h-11 w-11 rounded-2xl bg-slate-950 text-white grid place-items-center font-black shadow-lg">
          <img src="{{ asset('assets/img/logo.jpg') }}" alt="{{ $siteSettings->site_name }}">
        </div>
        <div>
          <div class="font-black tracking-tight text-lg">{{ $siteSettings->site_name }}</div>
          <div class="text-[11px] uppercase tracking-[.2em] text-slate-500">Virtual Mastercard</div>
        </div>
      </a>

      <div class="hidden lg:flex items-center gap-7 text-sm font-semibold text-slate-600">
        <a href="{{ route('home') }}#home" class="hover:text-slate-950">Home</a>
        <a href="{{ route('home') }}#features" class="hover:text-slate-950">Features</a>
        <a href="{{ route('home') }}#order" class="hover:text-slate-950">Order Card</a>
        <a href="{{ route('home') }}#steps" class="hover:text-slate-950">How it works</a>
        <a href="{{ route('home') }}#faq" class="hover:text-slate-950">FAQ</a>
        <a href="{{ route('home') }}#support" class="hover:text-slate-950">Support</a>
      </div>

      <div class="hidden lg:flex items-center gap-2">
        @auth
        @if(auth()->user()->role === 'admin')
        <a href="{{ route('admin.index') }}" class="inline-flex px-4 py-2.5 rounded-xl bg-slate-950 text-white text-sm font-bold hover:bg-slate-800">Dashboard</a>
        @elseif(auth()->user()->role === 'merchant')
        <div class="relative">
          <button type="button" onclick="toggleAccountMenu()" aria-controls="accountMenu" aria-expanded="false" class="inline-flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-4 py-2.5 text-sm font-bold hover:bg-slate-50">
            <span class="grid h-7 w-7 place-items-center rounded-full bg-emerald-100 text-emerald-700">{{ strtoupper(substr(auth()->user()->name, 0, 1)) }}</span>
            <span>{{ auth()->user()->name }}</span><span class="text-slate-400">⌄</span>
          </button>
          <div id="accountMenu" class="absolute right-0 mt-2 hidden w-52 rounded-2xl border border-slate-200 bg-white p-2 shadow-xl">
            <a href="{{ route('merchant.index') }}" class="block rounded-xl px-3 py-2.5 text-sm font-semibold hover:bg-slate-50">Dashboard</a>
            <a href="{{ route('profile.edit') }}" class="block rounded-xl px-3 py-2.5 text-sm font-semibold hover:bg-slate-50">Profile</a>
            <a href="{{ route('orders.index') }}" class="block rounded-xl px-3 py-2.5 text-sm font-semibold hover:bg-slate-50">My Orders</a>
            <a href="{{ route('cards.index') }}" class="block rounded-xl px-3 py-2.5 text-sm font-semibold hover:bg-slate-50">My Card</a>
            <form method="POST" action="{{ route('logout') }}" class="mt-1 border-t border-slate-100 pt-1">@csrf<button type="submit" class="block w-full rounded-xl px-3 py-2.5 text-left text-sm font-semibold text-red-600 hover:bg-red-50">Logout</button></form>
          </div>
        </div>
        @endif
        @else
        <a href="{{ route('login') }}" class="inline-flex px-4 py-2.5 rounded-xl border border-slate-200 bg-white text-sm font-bold hover:bg-slate-50">
          Login
        </a>
        <a href="{{ route('register') }}" class="inline-flex px-4 py-2.5 rounded-xl border border-emerald-200 bg-emerald-50 text-emerald-700 text-sm font-bold hover:bg-emerald-100">
          Register
        </a>
        @endauth
      </div>

      <div class="hidden lg:flex items-center rounded-xl border border-slate-200 bg-white p-1 text-xs font-black" aria-label="Language selector">
        <button type="button" data-language="en" class="language-option rounded-lg px-2.5 py-2 active">English</button>
        <button type="button" data-language="bn" class="language-option rounded-lg px-2.5 py-2">বাংলা</button>
      </div>

      <button type="button" onclick="toggleMobileMenu()" aria-controls="mobileMenu" aria-expanded="false" class="lg:hidden inline-flex h-11 w-11 items-center justify-center rounded-xl border border-slate-200 bg-white text-slate-700" aria-label="Open navigation menu">
        <span class="text-2xl leading-none">☰</span>
      </button>
    </nav>

    <div id="mobileMenu" class="hidden border-t border-slate-200/70 bg-white/95 px-4 pb-4 pt-3 shadow-lg lg:hidden">
      <div class="flex flex-col gap-1 text-sm font-semibold text-slate-700">
        <a href="{{ route('home') }}#home" onclick="closeMobileMenu()" class="rounded-xl px-4 py-3 hover:bg-slate-50">Home</a>
        <a href="{{ route('home') }}#features" onclick="closeMobileMenu()" class="rounded-xl px-4 py-3 hover:bg-slate-50">Features</a>
        <a href="{{ route('home') }}#order" onclick="closeMobileMenu()" class="rounded-xl px-4 py-3 hover:bg-slate-50">Order Card</a>
        <a href="{{ route('home') }}#steps" onclick="closeMobileMenu()" class="rounded-xl px-4 py-3 hover:bg-slate-50">How it works</a>
        <a href="{{ route('home') }}#faq" onclick="closeMobileMenu()" class="rounded-xl px-4 py-3 hover:bg-slate-50">FAQ</a>
        <a href="{{ route('home') }}#support" onclick="closeMobileMenu()" class="rounded-xl px-4 py-3 hover:bg-slate-50">Support</a>
      </div>
      <div class="mt-3 border-t border-slate-100 pt-3">
        <div class="mb-3 flex items-center justify-between rounded-xl bg-slate-50 px-3 py-2 text-xs font-black"><span>Language</span><div class="flex rounded-lg border border-slate-200 bg-white p-1"><button type="button" data-language="en" class="language-option rounded-md px-2 py-1 active">English</button><button type="button" data-language="bn" class="language-option rounded-md px-2 py-1">বাংলা</button></div></div>
        @auth
        @if(auth()->user()->role === 'admin')
          <a href="{{ route('admin.index') }}" onclick="closeMobileMenu()" class="block rounded-xl bg-slate-950 px-4 py-3 text-sm font-bold text-white hover:bg-slate-800">Dashboard</a>
        @elseif(auth()->user()->role === 'merchant')
        <div class="mb-2 rounded-xl bg-slate-50 px-4 py-3 text-sm font-bold text-slate-700">{{ auth()->user()->name }}</div>
        <a href="{{ route('merchant.index') }}" onclick="closeMobileMenu()" class="mb-1 block rounded-xl px-4 py-3 text-sm font-semibold hover:bg-slate-50">Dashboard</a>
        <a href="{{ route('profile.edit') }}" onclick="closeMobileMenu()" class="mb-1 block rounded-xl px-4 py-3 text-sm font-semibold hover:bg-slate-50">Profile</a>
        <a href="{{ route('orders.index') }}" onclick="closeMobileMenu()" class="mb-1 block rounded-xl px-4 py-3 text-sm font-semibold hover:bg-slate-50">My Orders</a>
        <a href="{{ route('cards.index') }}" onclick="closeMobileMenu()" class="mb-1 block rounded-xl px-4 py-3 text-sm font-semibold hover:bg-slate-50">My Card</a>
        @endif
        <form method="POST" action="{{ route('logout') }}">@csrf<button type="submit" class="w-full rounded-xl bg-slate-950 px-4 py-3 text-sm font-bold text-white hover:bg-slate-800">Logout</button></form>
        @else
        <a href="{{ route('login') }}" class="rounded-xl border border-slate-200 bg-white px-4 py-3 text-center text-sm font-bold text-slate-700 hover:bg-slate-50">Login</a>
        <a href="{{ route('register') }}" class="rounded-xl bg-emerald-600 px-4 py-3 text-center text-sm font-bold text-white hover:bg-emerald-700">Register</a>
        @endauth
      </div>
      <a href="#order" onclick="closeMobileMenu()" class="mt-2 block rounded-xl bg-slate-950 px-4 py-3 text-center text-sm font-bold text-white hover:bg-slate-800">Order your card</a>
    </div>
  </header>
@yield('content')

  
  <!-- Footer -->
  <footer class="bg-slate-950 text-slate-400">
    <div class="max-w-7xl mx-auto px-4 py-12">
      <div class="grid md:grid-cols-4 gap-8">
        <div class="md:col-span-2">
          <div class="text-white font-black text-xl">{{ $siteSettings->site_name }}</div>
          <p class="mt-3 max-w-md leading-7 text-sm">
            {{ $siteSettings->support_text ?: 'Fast and secure access to your virtual Mastercard for online payments.' }}
          </p>
        </div>
        <div>
          <div class="text-white font-bold mb-3">Quick Links</div>
          <div class="space-y-2 text-sm">
            <a href="{{ route('home') }}#order" class="block hover:text-white">Order Card</a>
            <a href="{{ route('home') }}#steps" class="block hover:text-white">How it works</a>
            <a href="{{ route('home') }}#faq" class="block hover:text-white">FAQ</a>
          </div>
        </div>
        <div>
          <div class="text-white font-bold mb-3">Legal</div>
          <div class="space-y-2 text-sm">
            <a href="{{ route('legal.privacy') }}" class="block hover:text-white">Privacy Policy</a>
            <a href="{{ route('legal.terms') }}" class="block hover:text-white">Terms of Service</a>
            <a href="{{ route('legal.refund') }}" class="block hover:text-white">Refund Policy</a>
          </div>
        </div>
      </div>

      <div class="border-t border-white/10 mt-10 pt-6 flex flex-col sm:flex-row justify-between gap-3 text-xs">
        <span>© 2026 {{ $siteSettings->site_name }}. All rights reserved.</span>
        <span>Use safely • Keep your card details private</span>
      </div>
    </div>
  </footer>

  <!-- Toast -->
  <div id="toast" class="fixed right-4 bottom-4 z-[100] hidden max-w-sm rounded-2xl bg-slate-950 text-white px-5 py-4 shadow-2xl text-sm"></div>

  <script>
    function showToast(message) {
      const toast = document.getElementById('toast');
      toast.textContent = message;
      toast.classList.remove('hidden');
      clearTimeout(window.toastTimer);
      window.toastTimer = setTimeout(() => toast.classList.add('hidden'), 4000);
    }

    function toggleMobileMenu() {
      const menu = document.getElementById('mobileMenu');
      const button = document.querySelector('[aria-controls="mobileMenu"]');
      const isOpen = !menu.classList.contains('hidden');

      menu.classList.toggle('hidden', isOpen);
      button.setAttribute('aria-expanded', String(!isOpen));
      button.setAttribute('aria-label', isOpen ? 'Open navigation menu' : 'Close navigation menu');
    }

    function closeMobileMenu() {
      const menu = document.getElementById('mobileMenu');
      const button = document.querySelector('[aria-controls="mobileMenu"]');

      menu.classList.add('hidden');
      button.setAttribute('aria-expanded', 'false');
      button.setAttribute('aria-label', 'Open navigation menu');
    }

    function toggleAccountMenu() {
      const menu = document.getElementById('accountMenu');
      const button = document.querySelector('[aria-controls="accountMenu"]');
      const isOpen = !menu.classList.contains('hidden');
      menu.classList.toggle('hidden', isOpen);
      button.setAttribute('aria-expanded', String(!isOpen));
    }

    const interfaceTranslations = {
      'হোম': 'Home', 'সুবিধা': 'Features', 'কার্ড অর্ডার': 'Order card', 'প্রক্রিয়া': 'How it works', 'জিজ্ঞাসা': 'FAQ', 'যোগাযোগ': 'Support',
      'লগইন': 'Log in', 'রেজিস্টার': 'Register', 'প্রোফাইল': 'Profile', 'কীভাবে কাজ করে': 'How it works', 'সাধারণ প্রশ্ন': 'FAQ',
      'কার্ড অর্ডার করুন': 'Order your card', 'বিস্তারিত দেখুন': 'Explore details', 'ভার্চুয়াল কার্ড অর্ডার চালু আছে': 'Virtual card orders are open',
      'অনলাইন পেমেন্টের জন্য': 'For online payments', 'আপনার ভার্চুয়াল কার্ড।': 'Your virtual card.',
      'কয়েক মিনিটের মধ্যে একটি নিরাপদ ভার্চুয়াল Mastercard নিন। অনলাইন শপিং, সাবস্ক্রিপশন ও আন্তর্জাতিক পেমেন্ট এখন আরও সহজ।': 'Get a secure virtual Mastercard in minutes. Online shopping, subscriptions and international payments are now easier.',
      '✓ দ্রুত ডেলিভারি': '✓ Fast delivery', '✓ নিরাপদ পেমেন্ট': '✓ Secure payments', '✓ ২৪/৭ সাপোর্ট': '✓ 24/7 support',
      'কেন payoneercard': 'Why payoneercard', 'আপনার অনলাইন পেমেন্ট আরও সহজ হোক।': 'Make online payments easier.',
      'একটি কার্ডেই অনলাইন কেনাকাটা, সফটওয়্যার সাবস্ক্রিপশন এবং আন্তর্জাতিক সার্ভিসের পেমেন্ট করুন।': 'Use one card for online shopping, software subscriptions and international services.',
      'দ্রুত অ্যাক্টিভেশন': 'Fast activation', 'আন্তর্জাতিক পেমেন্ট': 'International payments', 'বিশ্বস্ত সাপোর্ট': 'Trusted support',
      'কার্ড প্যাকেজ': 'Card packages', 'আপনার পছন্দের কার্ড আজই নিন।': 'Choose your card today.', 'কোনো পণ্য বর্তমানে উপলভ্য নেই।': 'No products are currently available.',
      'Active': 'Active', 'এই কার্ডটি অর্ডার করুন →': 'Order this card →', 'মাত্র তিনটি ধাপে কার্ড নিন': 'Get your card in three steps',
      'অর্ডার পাঠান': 'Place your order', 'পেমেন্ট নিশ্চিত করুন': 'Confirm payment', 'কার্ড ব্যবহার করুন': 'Use your card',
      'আপনার যা জানা দরকার': 'What you need to know', 'সহায়তা দরকার?': 'Need help?', 'আমাদের টিম আপনার পাশে আছে।': 'Our team is here for you.',
      'অর্ডার বা কার্ড ব্যবহার নিয়ে যেকোনো প্রশ্নে যোগাযোগ করুন।': 'Contact us with any question about your order or card.', 'ইমেইল করুন': 'Email us',
      'অর্ডার ফর্ম': 'Order form', 'পরিশোধযোগ্য': 'Total due', 'পণ্যের তালিকায় ফিরুন': 'Back to products', 'Payment করুন এই account-এ': 'Make payment to this account',
      'আপনার তথ্য': 'Your details', 'আপনার নাম *': 'Full name *', 'ইমেইল *': 'Email *', 'মোবাইল নম্বর *': 'Phone number *', 'Payment details': 'Payment details', 'পেমেন্ট মাধ্যম *': 'Payment method *', 'নির্বাচন করুন': 'Select one',
      'যে নম্বর/অ্যাকাউন্ট থেকে পেমেন্ট করেছেন *': 'Payment number or account *', 'Delivery Address *': 'Delivery address *', 'পেমেন্ট স্লিপ *': 'Payment slip *', 'অর্ডার জমা দিন': 'Submit order',
      'এই account-এ payment করুন': 'Pay to this account', 'পরিশোধযোগ্য': 'Total due', 'অর্ডার জমা হয়েছে।': 'Order submitted.',
      'Privacy Policy': 'Privacy Policy', 'সেবার শর্তাবলী': 'Terms of service', 'রিফান্ড নীতি': 'Refund policy',
      'নিরাপদে ব্যবহার করুন • কার্ডের তথ্য গোপন রাখুন': 'Use safely • Keep your card details private'
    };

    const reverseTranslations = Object.fromEntries(Object.entries(interfaceTranslations).map(([bangla, english]) => [english, bangla]));

    function setLanguage(language) {
      const dictionary = language === 'en' ? interfaceTranslations : reverseTranslations;
      document.documentElement.lang = language;
      document.querySelectorAll('.language-option').forEach((option) => option.classList.toggle('active', option.dataset.language === language));
      const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
      const textNodes = [];
      while (walker.nextNode()) textNodes.push(walker.currentNode);
      textNodes.forEach((node) => {
        if (node.parentElement.closest('script, style, [data-language]')) return;
        const value = node.nodeValue;
        const trimmed = value.trim();
        if (dictionary[trimmed]) node.nodeValue = value.replace(trimmed, dictionary[trimmed]);
      });
      localStorage.setItem('site-language', language);
    }

    document.querySelectorAll('.language-option').forEach((option) => option.addEventListener('click', () => setLanguage(option.dataset.language)));
    setLanguage(localStorage.getItem('site-language') || 'en');

  </script>
</body>
</html>
