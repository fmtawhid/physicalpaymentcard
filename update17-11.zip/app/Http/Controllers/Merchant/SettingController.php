<?php

namespace App\Http\Controllers\Merchant;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rule;

class SettingController extends Controller
{
    // Show edit form
    public function index()
    {
        $user = Auth::user();
        $merchant = $user->merchant()->firstOrCreate([], [
            'name' => $user->name,
            'email' => $user->email,
            'phone' => $user->phone ?: '',
        ]);

        return view('merchant.setting.edit_info', compact('user', 'merchant'));
    }

    // Update info
    public function update(Request $request)
    {
        $user = Auth::user();
        $merchant = $user->merchant()->firstOrCreate([], [
            'name' => $user->name,
            'email' => $user->email,
            'phone' => $user->phone ?: '',
        ]);

        $request->validate([
            'name' => 'required|string|max:255',
            'email' => "required|email|unique:users,email,".$user->id,
            'phone' => 'required|string|max:30',
            'country' => ['required', Rule::in(config('locations.countries'))],
            'district' => ['required', Rule::in(config('locations.districts'))],
            'delivery_address' => 'required|string|max:1000',
            'nid_number' => 'nullable|string|max:50',
            'nid_front' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            'nid_back' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            'logo' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            'status' => 'required|in:active,inactive',
        ]);

        // Handle file uploads
        $logoName = $merchant->logo;
        $nidFrontName = $merchant->nid_front;
        $nidBackName = $merchant->nid_back;

        if ($request->hasFile('logo')) {
            if($logoName && file_exists(public_path('uploads/merchants/'.$logoName))) unlink(public_path('uploads/merchants/'.$logoName));
            $logoName = time().'_logo.'.$request->logo->extension();
            $request->logo->move(public_path('uploads/merchants'), $logoName);
        }

        if ($request->hasFile('nid_front')) {
            if($nidFrontName && file_exists(public_path('uploads/merchants/'.$nidFrontName))) unlink(public_path('uploads/merchants/'.$nidFrontName));
            $nidFrontName = time().'_nid_front.'.$request->nid_front->extension();
            $request->nid_front->move(public_path('uploads/merchants'), $nidFrontName);
        }

        if ($request->hasFile('nid_back')) {
            if($nidBackName && file_exists(public_path('uploads/merchants/'.$nidBackName))) unlink(public_path('uploads/merchants/'.$nidBackName));
            $nidBackName = time().'_nid_back.'.$request->nid_back->extension();
            $request->nid_back->move(public_path('uploads/merchants'), $nidBackName);
        }

        // Update merchant
        $merchant->update([
            'name' => $request->name,
            'email' => $request->email,
            'phone' => $request->phone,
            'store_name' => $request->store_name,
            'bank_info' => $request->bank_info,
            'nid_number' => $request->nid_number,
            'nid_front' => $nidFrontName,
            'nid_back' => $nidBackName,
            'logo' => $logoName,
            'status' => $request->status,
        ]);

        // Update user
        $user->update([
            'name' => $request->name,
            'email' => $request->email,
            'phone' => $request->phone,
            'country' => $request->country,
            'district' => $request->district,
            'delivery_address' => $request->delivery_address,
        ]);

        return redirect()->route('merchant.settings.edit')->with('success', 'Your merchant profile has been updated successfully.');
    }
}
